Action()
{

	web_add_cookie("PHPSESSID=1cc80924ccfa386761566986283992a1; DOMAIN=192.168.129.196");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("index.html", 
		"URL=http://192.168.129.196/home/login/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t378.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://192.168.129.196");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(10);

	web_submit_data("login_submit", 
		"Action=http://192.168.129.196/home/login/login_submit", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/login/index.html", 
		"Snapshot=t379.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=lixiaobin", ENDITEM, 
		"Name=password", "Value=123456", ENDITEM, 
		"Name=captcha", "Value=30", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.129.196", 
		"URL=http://192.168.129.196/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.129.196/home/login/index.html", 
		"Snapshot=t380.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("get_note_list", 
		"URL=http://192.168.129.196/home/api/get_note_list?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t381.inf", 
		"Mode=HTML", 
		LAST);

	web_url("get_article_list", 
		"URL=http://192.168.129.196/home/api/get_article_list?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t382.inf", 
		"Mode=HTML", 
		LAST);

	web_url("get_view_data", 
		"URL=http://192.168.129.196/home/api/get_view_data", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t383.inf", 
		"Mode=HTML", 
		LAST);

	web_url("get_view_log", 
		"URL=http://192.168.129.196/home/api/get_view_log", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t384.inf", 
		"Mode=HTML", 
		LAST);

	web_url("log_list", 
		"URL=http://192.168.129.196/home/api/log_list?page=1&limit=20", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t385.inf", 
		"Mode=HTML", 
		LAST);

	web_url("get_article_list_2", 
		"URL=http://192.168.129.196/home/api/get_article_list?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t386.inf", 
		"Mode=HTML", 
		LAST);

	web_url("get_view_data_2", 
		"URL=http://192.168.129.196/home/api/get_view_data", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/index/main.html", 
		"Snapshot=t387.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"kbgigmcnifmaklccibmlepmahpfdhjch,nhdogjmejiglipccpnnnanhbledajbpd,nmmhkkegccagdldgiimedpiccmgmieda");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-120.0.6099.129");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:Lfd_izrinfKv66mRauAu6G4ujYfb5NMaj3_By0jWxEk&cup2hreq=b076ae28f223867eeee680008ed599a99faf087aff6428fff265ce47148f891a", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t388.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"kbgigmcnifmaklccibmlepmahpfdhjch\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.73e69b89448134fc3f1785450b7cfa6a323dfe791e5c0f97a150279d1ba589aa\"}]},\"ping\":{\"ping_freshness\":\"{90447ee1-427e-43fe-a0c0-c1634e030cda}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"0.2.9\"},{\"appid\""
		":\"nhdogjmejiglipccpnnnanhbledajbpd\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.ae69ebb7a546c360f81fecb4b75a420df107d609ea746a70864f4c2e585c1de2\"}]},\"ping\":{\"ping_freshness\":\"{6214626c-9ff2-47bd-8d25-2c0ce9caa003}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"6.5.1\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\""
		"other\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.81e3a4d43a73699e1b7781723f56b8717175c536685c5450122b30789464ad82\"}]},\"ping\":{\"ping_freshness\":\"{ce22810b-8055-4f3f-87a4-88bf0dfe4c00}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{"
		"\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"120.0.6099.129\",\"protocol\":\"3.1\",\"requestid\":\"{c0edacea-c7b5-494d-beb0-d95dee728501}\",\"sessionid\":\"{77983049-7c84-4d2c-ae56-74c7782c63b6}\",\"updaterversion\":\"120.0.6099.129\"}}", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=120", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t389.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("flow_type", 
		"URL=http://192.168.129.196/home/cate/flow_type", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.129.196/", 
		"Snapshot=t390.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("gougutab={\"tab_id\":\"32\",\"tab_array\":[{\"id\":\"32\",\"url\":\"/home/cate/flow_type\",\"title\":\"审批类型\"}]}; DOMAIN=192.168.129.196");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("flow_type_2", 
		"URL=http://192.168.129.196/home/cate/flow_type?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t391.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("flow_type_add", 
		"URL=http://192.168.129.196/home/cate/flow_type_add", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t392.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("get_department_select", 
		"URL=http://192.168.129.196/api/index/get_department_select?keyword=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type_add", 
		"Snapshot=t393.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://192.168.129.196");

	web_custom_request("index", 
		"URL=http://192.168.129.196/home/index/index", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/", 
		"Snapshot=t394.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_think_time(10);

	web_custom_request("index_2", 
		"URL=http://192.168.129.196/home/index/index", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/", 
		"Snapshot=t395.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("flow_type_add_2", 
		"Action=http://192.168.129.196/home/cate/flow_type_add", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type_add", 
		"Snapshot=t396.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=type", "Value=1", ENDITEM, 
		"Name=title", "Value=test4", ENDITEM, 
		"Name=department_ids", "Value=", ENDITEM, 
		"Name=name", "Value=testfour", ENDITEM, 
		"Name=icon", "Value=icon-jichupeizhi", ENDITEM, 
		"Name=id", "Value=0", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_url("flow_type_3", 
		"URL=http://192.168.129.196/home/cate/flow_type?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t397.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(7);

	web_url("flow_type_add_3", 
		"URL=http://192.168.129.196/home/cate/flow_type_add?id=28", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t398.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("get_department_select_2", 
		"URL=http://192.168.129.196/api/index/get_department_select?keyword=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type_add?id=28", 
		"Snapshot=t399.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://192.168.129.196");

	web_custom_request("index_3", 
		"URL=http://192.168.129.196/home/index/index", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/", 
		"Snapshot=t400.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("flow_type_add_4", 
		"Action=http://192.168.129.196/home/cate/flow_type_add", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type_add?id=28", 
		"Snapshot=t401.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=type", "Value=1", ENDITEM, 
		"Name=title", "Value=test44444", ENDITEM, 
		"Name=department_ids", "Value=", ENDITEM, 
		"Name=name", "Value=testfourfour", ENDITEM, 
		"Name=icon", "Value=icon-jichupeizhi", ENDITEM, 
		"Name=id", "Value=28", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_url("flow_type_4", 
		"URL=http://192.168.129.196/home/cate/flow_type?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t402.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://192.168.129.196");

	lr_think_time(5);

	web_custom_request("index_4", 
		"URL=http://192.168.129.196/home/index/index", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/", 
		"Snapshot=t403.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_submit_data("flow_type_check", 
		"Action=http://192.168.129.196/home/cate/flow_type_check", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t404.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=id", "Value=28", ENDITEM, 
		"Name=status", "Value=0", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_url("flow_type_5", 
		"URL=http://192.168.129.196/home/cate/flow_type?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t405.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://192.168.129.196");

	web_submit_data("flow_type_check_2", 
		"Action=http://192.168.129.196/home/cate/flow_type_check", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t406.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=id", "Value=28", ENDITEM, 
		"Name=status", "Value=1", ENDITEM, 
		LAST);

	web_url("flow_type_6", 
		"URL=http://192.168.129.196/home/cate/flow_type?page=1&limit=10", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.129.196/home/cate/flow_type", 
		"Snapshot=t407.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Chrome-UMA-Log-HMAC-SHA256", 
		"IJ88R4WCKNSbzI4OBlUroVkWWdkd/ac/BM33OLZPdzQ=");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"2AFFF59A3AAE9BC7ACAA1002E9FA67DD3BCEFBE1");

	web_add_header("X-Chrome-UMA-ReportingInfo", 
		"CAE=");

	web_custom_request("v2", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t408.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"Body=\tv���F���\b�ć�120.0.6099.129-64���\"zh-CN*\n\nWindows NT\n10.0.190452�\nx86_64�]��Ȁ��\"80WA(0�8�B�\b����\r21.20.16.46272Google Inc. (Intel):bANGLE (Intel, Intel(R) HD Graphics 630 (0x0000591B) Direct3D11 vs_5_0 ps_5_0, D3D11-21.20.16.4627)MqG�BU%��Be", 
		LAST);

	return 0;
}