Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=120", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"kbgigmcnifmaklccibmlepmahpfdhjch,nhdogjmejiglipccpnnnanhbledajbpd,nmmhkkegccagdldgiimedpiccmgmieda");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-120.0.6099.129");

	lr_think_time(11);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:kwuGvD0rudrZ88CYPPuRd3FhxNF8rJdC60sLYUe3PdI&cup2hreq=426ea632d901d8b765bee283063c156fb79c8350d43b6c6f38cea08673d2c03a", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"kbgigmcnifmaklccibmlepmahpfdhjch\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.73e69b89448134fc3f1785450b7cfa6a323dfe791e5c0f97a150279d1ba589aa\"}]},\"ping\":{\"ping_freshness\":\"{4ebbe1d1-d300-45a0-9159-5b0c8cfe0c2d}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"0.2.9\"},{\"appid\""
		":\"nhdogjmejiglipccpnnnanhbledajbpd\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.ae69ebb7a546c360f81fecb4b75a420df107d609ea746a70864f4c2e585c1de2\"}]},\"ping\":{\"ping_freshness\":\"{87f8fdd7-4e11-4fdc-a892-6d5aa70e243f}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"6.5.1\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5798,\"installedby\":\""
		"other\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.81e3a4d43a73699e1b7781723f56b8717175c536685c5450122b30789464ad82\"}]},\"ping\":{\"ping_freshness\":\"{f12dae69-2258-4b62-9c82-db1ad4ee7e4e}\",\"rd\":6200},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{"
		"\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"120.0.6099.129\",\"protocol\":\"3.1\",\"requestid\":\"{68d25e27-5418-49b3-b1fa-4678c19a90a7}\",\"sessionid\":\"{4ffd7929-6b75-4ad7-822b-bd24eaa7ea4f}\",\"updaterversion\":\"120.0.6099.129\"}}", 
		LAST);

	lr_think_time(6);

	web_url("group.png", 
		"URL=https://pub.idqqimg.com/wpa/images/group.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost/", 
		"Snapshot=t43.inf", 
		LAST);

	return 0;
}